package com.app.androidassesment.data

data class Name(
    val firstname: String,
    val lastname: String
)