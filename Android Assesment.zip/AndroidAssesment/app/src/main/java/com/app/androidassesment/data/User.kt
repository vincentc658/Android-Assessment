package com.app.androidassesment.data

data class User(
    val username: String,
    val password: String,
    val token: String=""
)