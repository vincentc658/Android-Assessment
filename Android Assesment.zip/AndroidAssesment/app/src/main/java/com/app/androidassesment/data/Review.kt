package com.app.androidassesment.data

data class Review(
    val name: String="Dummy Reviewer",
    val text: String="This is just dummy review for this product",
)